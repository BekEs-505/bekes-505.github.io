#import <Preferences/PSSpecifier.h>
#import <Preferences/PSSwitchTableCell.h>
#import "../HUtilities/HCommon.h"
#import "HPSRootListController.h"

@interface HPSSwitchCell : PSSwitchTableCell
@end
