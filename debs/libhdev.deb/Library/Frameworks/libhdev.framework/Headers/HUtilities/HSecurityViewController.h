#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <LocalAuthentication/LocalAuthentication.h>

@interface HSecurityViewController : UIViewController
- (void)authenticate;
@end